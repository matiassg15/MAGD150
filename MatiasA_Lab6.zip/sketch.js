let starX = []; // X positions of stars
let starY = []; // Y positions of stars
let starSize = []; // Size of each star

function setup() {
  createCanvas(240, 120);
  noStroke();
  fill(255, 255, 200); // soft yellow-white

  // Create 500 stars with random positions and sizes
  for (let a = 0; a < 300; a++) {
    starX[a] = random(-1000, width);
    starY[a] = random(height);
    starSize[a] = random(2, 4);
  }
}

function draw() {
  background(0);

  // Draw and move stars
  for (let a = 0; a < starX.length; a++) {
    // Move stars to the left
    starX[a] += 0.5;

    // If a star moves off screen, reset it to the right
    if (starX[a] > width) {
      starX[a] = random(-100, 0);
      starY[a] = random(height);
    }

    // Draw the star as a large circle
    ellipse(starX[a], starY[a], starSize[a], starSize[a]);
  }
}


