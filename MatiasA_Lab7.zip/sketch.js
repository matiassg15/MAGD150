let moons = ["Selune", "Selenite", "Artemis", "Aine", "Mani", "Boinn"];
let myMoons = [];
let myMoonsX = [];
let myMoonsY = [];

function setup() {
  createCanvas(400, 400);
  background(220);
  fill(255);
  noStroke();

  // pick 5 random moons
  for (let p = 0; p < 5; p++) {
    let num = Math.floor(random(0, moons.length));
    console.log(num);
    myMoons.push(moons[num]);
    moons.splice(num, 1);
    myMoonsX.push(random(10, width - 30));
    myMoonsY.push(random(10, height - 50));
  }

  // draw crescent shapes with moon names
  for (let r = 0; r < myMoons.length; r++) {
    drawCrescent(myMoonsX[r], myMoonsY[r], 50);
    text(myMoons[r], myMoonsX[r] - 15, myMoonsY[r] + 40);
  }

  // show remaining moon name
  text("The remaining moon was " + moons[0], width / 4, height - 20);
}

// crescent drawing function
function drawCrescent(x, y, s) {
  fill(255, 255, 150);
  circle(x, y, s);
  fill(20);
  circle(x + 10, y, s);
}
